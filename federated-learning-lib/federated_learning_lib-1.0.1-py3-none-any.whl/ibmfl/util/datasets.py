"""
Licensed Materials - Property of IBM
Restricted Materials of IBM
20190891
© Copyright IBM Corp. 2020 All Rights Reserved.
"""
"""
Module providing utility functions for loading datasets for use in FL
"""
import os
import sys
import shutil
from zipfile import ZipFile

import numpy as np
import pandas as pd
import requests


def save_file(path, url):
    """
    Saves a file from URL to path

    :param path: the path to save the file
    :type path; `str`
    :param url: the link to download from
    :type url: `str`
    """
    with requests.get(url, stream=True, verify=False) as r:
        with open(path, 'wb') as f:
            shutil.copyfileobj(r.raw, f)


def load_mnist(normalize=True, download_dir=""):
    """
    Download MNIST training data from source used in `keras.datasets.load_mnist`
    :param normalize: whether or not to normalize data
    :type normalize: bool
    :param download_dir: directory to download data
    :type download_dir: `str`
    :return: 2 tuples containing training and testing data respectively
    :rtype (`np.ndarray`, `np.ndarray`), (`np.ndarray`, `np.ndarray`)
    """
    local_file = os.path.join(download_dir, "mnist.npz")
    if not os.path.isfile(local_file):
        save_file(local_file, "https://s3.amazonaws.com/img-datasets/mnist.npz")

    with np.load(local_file, allow_pickle=True) as mnist:
        x_train, y_train = mnist['x_train'], mnist['y_train']
        x_test, y_test = mnist['x_test'], mnist['y_test']
        if normalize:
            x_train = x_train.astype('float32')
            x_test = x_test.astype('float32')

            x_train /= 255
            x_test /= 255

    return (x_train, y_train), (x_test, y_test)


def load_nursery(download_dir=""):
    """
    Download Nursery training data set

    :param download_dir: directory to download data
    :type download_dir: `str`
    :return: training dataset for data set
    :rtype: `pandas.core.frame.DataFrame`
    """
    local_file = os.path.join(download_dir, "nursery.data")
    if not os.path.isfile(local_file):
        save_file(
            local_file, "https://archive.ics.uci.edu/ml/machine-learning-databases/nursery/nursery.data")
    training_dataset = pd.read_csv(local_file, dtype='category', header=None)
    # url data does not have label for each column,
    # so insert column labels here.
    training_dataset.columns = ['1', '2', '3', '4', '5', '6', '7',
                                '8', 'class']
    return training_dataset


def load_adult(download_dir=""):
    """
    Download Adult training data set,
    and perform the following pre-processing steps:
        * Drop `fnlwgt` feature
        * Add column labels ['1', '2', '3'...'13', 'class']

    :param download_dir: directory to download data
    :type download_dir: `str`
    :return: training dataset for data set
    :rtype: `pandas.core.frame.DataFrame`
    """
    local_file = os.path.join(download_dir, "adult.data")
    if not os.path.isfile(local_file):
        save_file(
            local_file, "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data")
    training_dataset = pd.read_csv(local_file, dtype='category', header=None)

    # drop 'fnlwgt' column
    training_dataset = training_dataset.drop(
        training_dataset.columns[2], axis='columns')

    # url data does not have label for each column,
    # so insert column labels here.
    training_dataset.columns = ['1', '2', '3', '4', '5', '6', '7',
                                '8', '9', '10', '11', '12', '13', 'class']

    return training_dataset


def load_german(download_dir=""):
    """
    Download German Credit Scoring training data set, and add column labels ['1', '2', '3'...'13', 'class']
    :param download_dir: directory to download data
    :type download_dir: `str`
    :return: training dataset for data set
    :rtype: `pandas.core.frame.DataFrame`
    """
    local_file = os.path.join(download_dir, "german.data")
    if not os.path.isfile(local_file):
        save_file(
            local_file, "https://archive.ics.uci.edu/ml/machine-learning-databases/statlog/german/german.data")
    training_dataset = pd.read_csv(
        local_file, sep=' ', dtype='category', header=None)
    # url data does not have label for each column,
    # so insert column labels here.
    training_dataset.columns = ['1', '2', '3', '4', '5', '6', '7',
                                '8', '9', '10', '11', '12', '13', '14',
                                '15', '16', '17', '18', '19', '20', 'class']
    return training_dataset


def load_compas(download_dir=""):
    """
    Download Compas (ProPublica recidivism) training data set and rename 'two_year_recid' to 'class':
    :param download_dir: directory to download data
    :type download_dir: `str`
    :return: training dataset for data set
    :rtype: `pandas.core.frame.DataFrame`
    """
    local_file = os.path.join(download_dir, "compas-scores-two-years.csv")
    training_dataset = pd.read_csv(local_file)
    training_dataset['class'] = training_dataset['two_year_recid']
    training_dataset = training_dataset.drop('two_year_recid', axis=1)

    return training_dataset


def load_binovf():
    """
    Generate Binary Classification Overfit - Based on features where all 0 class
    label values are derived with 0 features and similarly for 1 class labels.
    Generates a sample of 1,000 data points with univariate features, 500 for
    each class.

    :return: Generated training dataset for data set for Binary Overfit set.
    :rtype: `tuple` of (`np.ndarray`, `np.ndarray`)
    """
    X, y = np.zeros((1000, 1)), np.zeros((1000))
    X[500:, :] = np.ones((500, 1))
    y[500:] = np.ones((500))

    return X, y


def load_multovf():
    """
    Generate Multiclass Classification Overfit - Based on features where all 0 class
    label values are derived with 0 features and similarly for 1 class labels.
    Generates a sample of 1,000 data points with univariate features, 500 for
    each class.

    :return: Generated training dataset for data set for Multiclass Overfit set.
    :rtype: `tuple` of (`np.ndarray`, `np.ndarray`)
    """
    X, y = np.zeros((1000, 3)), np.zeros((1000))
    for i, x in enumerate(range(200, 1000, 200)):
        X[x:x+200, :] = np.ones((200, 3)) * i
        y[x:x+200] = np.ones((200)) * i

    return X, y


def load_linovf():
    """
    Generate RegressionOverfit Data - Based on a 1 to 1 linear relationship of the
    input to the output values. Generates a sample of 1,000 data points with
    univariate features. (Models a perfect y = x relationship)

    :return: Generated training dataset for data set for Linear Overfit set.
    :rtype: `tuple` of (`np.ndarray`, `np.ndarray`)
    """
    data = np.random.uniform(0, 100, 1000)
    X, y = data, data
    return X, y


def load_higgs(download_dir=""):
    """
    Download Higgs Boson training dataset, and append column labels.

    :param download_dir: directory to download data
    :type download_dir: `str`
    :return: Training dataset for data set.
    :rtype: `tuple` of (`np.ndarray`, `np.ndarray`)
    """
    # Define Local Donwload Directory
    local_file = os.path.join(download_dir, "HIGGS.csv.gz")

    # Download File If Not Present in System
    if not os.path.isfile(local_file):
        print('Dataset not available in directory, downloading from source...')
        save_file(
            local_file, 'https://archive.ics.uci.edu/ml/machine-learning-databases/00280/HIGGS.csv.gz')

    # Load Dataset
    print('Loading dataset from ' + local_file)
    data = pd.read_csv(local_file, compression='gzip', header=None).to_numpy()

    # Parse Column Features and Target and Return Values
    return data[:, 1:], data[:, 0]


def load_airline(download_dir=""):
    """
    Download Airline Arrivals Dataset. To simplify data preprocessing, we
    perform this here instead at the DataLoader end to offset the process.
    Preprocessing includes: i) dropping data leaked features, ii) categorical
    encoding, iii) dropping features, and iv) one hot encoding.

    :param download_dir: directory to download data
    :type download_dir: `str`
    :return: Training dataset for data set.
    :rtype: `tuple` of (`np.ndarray`, `np.ndarray`)
    """
    # Define Local Donwload Directory
    local_file = os.path.join(download_dir, "DelayedFlights.csv")

    # Download File If Not Present in System
    if not os.path.isfile(local_file):
        print('Please download the csv file directly from the source ' +
              'https://www.kaggle.com/giovamata/airlinedelaycauses and extract ' +
              'and save the csv file under the examples/datasets/ directory.')
        sys.exit()

    # Load Dataset
    print('Loading dataset from ' + local_file)
    data = pd.read_csv(local_file)

    # Define Auxillary Function
    def get_dtypes(data, features):
        output = {}
        for f in features:
            dtype = str(data[f].dtype)
            if dtype not in output.keys():
                output[dtype] = [f]
            else:
                output[dtype] += [f]
        return output

    # Drop Unecessary & Leaky Features
    data = data.drop("Unnamed: 0", 1)

    target = ["Cancelled"]
    leaky_features = ["Year", "Diverted", "ArrTime", "ActualElapsedTime",
                      "AirTime", "ActualElapsedTime", "AirTime", "ArrDelay",
                      "TaxiIn", "CarrierDelay", "WeatherDelay", "NASDelay",
                      "SecurityDelay", "LateAircraftDelay", "CancellationCode"]

    features = [x for x in data.columns if (x != target[0]) & (x not in
                                                               leaky_features) & (len(data[x].unique().tolist()) > 1)]

    data = data[data["Month"].isin([10, 11, 12])]

    dtypes = get_dtypes(data, features)

    # Categorical and Numerical Feature Selection
    categories = ["Month", "DayOfWeek", "DayofMonth"]
    categories += dtypes["object"]
    numerics = [i for i in dtypes["int64"] if i not in categories]
    numerics += dtypes["float64"]

    for numeric in numerics:
        data[numeric] = data[numeric].fillna(0)
    categories.remove("TailNum")

    cancelled = data[data[target[0]] == 1]
    not_cancelled = data[data[target[0]] == 0]

    data = pd.concat([cancelled, not_cancelled.sample(n=len(cancelled))], 0)

    one_hot_encoded = pd.get_dummies(data[categories].fillna("Unknown"))
    X = pd.concat([one_hot_encoded, data[numerics].fillna(0)], 1)
    y = data[target[0]]

    return X.to_numpy(), y.to_numpy()


def load_diabetes(download_dir=""):
    """
    Download Diabetese Dataset from source.  To simplify data preprocessing, we
    perform this here instead at the DataLoader end to offset the process.
    Preprocessing includes primarily feature dropping.

    :param download_dir: directory to download data
    :type download_dir: `str`
    :return: training dataset for data set
    :rtype: `np.ndarray`, `np.ndarray`
    """
    # Define Local Donwload Directory
    local_file = os.path.join(download_dir, "diabetic_data.csv")

    # Download File If Not Present in System
    if not os.path.isfile(local_file):
        # Download Raw Data
        print('Dataset not available in directory, downloading from source...')
        zip_dir = os.path.join(download_dir, 'dataset_diabetes.zip')
        save_file(
            zip_dir, 'https://archive.ics.uci.edu/ml/machine-learning-databases/00296/dataset_diabetes.zip')

        # Extract Content
        zip = ZipFile(os.path.join(download_dir, 'dataset_diabetes.zip'))
        zip.extractall(download_dir)
        zip.close()

        # Cleanup File Directory
        os.rename(os.path.join(download_dir, 'dataset_diabetes/diabetic_data.csv'),
                  os.path.join(download_dir, 'diabetic_data.csv'))
        os.remove(zip_dir)
        shutil.rmtree(os.path.join(download_dir, 'dataset_diabetes/'))

    # Load Dataset
    print('Loading dataset from ' + local_file)
    data = pd.read_csv(local_file)

    # Drop Features
    drop_id = ['encounter_id', 'patient_nbr', 'race', 'weight', 'payer_code',
               'medical_specialty', 'diag_1', 'diag_2', 'diag_3']
    data = data.drop(drop_id, axis=1)

    return data


def load_simulated_federated_clustering(**kwargs):
    r"""
    Generates a simulated federated clustering dataset as described in
    [https://arxiv.org/abs/1911.00218]. `L` true global centroids generate a
    `D` dimensional data partitioned in `J` clients.
    :param \**kwargs
            See below
    :Keyword Arguments:
        * *L* (``int``) -- Number of true global centroids, default 50
        * *J* (``int``) -- Number of clients, default 10
        * *D* (``int``) -- Data dimension, default 50
        * *M* (``int``) -- Data points per group, default 1000
        * *mu0* (``float``) -- Global mean, default 0.0
        * *global_sd* (``float``) -- Global standard deviation, default `np.sqrt(L)`
        * *local_sd* (``float``) -- Local standard deviation, default 1.0
    :return: generated data of shape (J, M, D)
    :rtype: `np.ndarray`
    """

    # Number of global centroids
    L = kwargs.get('L', 50)
    J = kwargs.get('J', 10)                             # Number of clients
    D = kwargs.get('D', 50)                             # Data dimension
    # data points per group
    M = kwargs.get('M', 1000)
    mu0 = kwargs.get('mu0', 0)                          # Global mean
    # Global standard deviation
    global_sd = kwargs.get('global_sd', np.sqrt(L))
    # Local standard deviation
    local_sd = kwargs.get('local_sd', 1.0)

    a, b = 1, 1
    global_p = np.random.beta(a=a, b=b, size=L)
    global_atoms = np.random.normal(
        mu0, global_sd, size=(L, D))    # Global set of centroids

    data = []       # data will be (J, M, D) dimensional array
    used_components = set()
    atoms = []

    for j in range(J):
        atoms_j_idx = [l for l in range(
            L) if np.random.binomial(1, global_p[l])]
        used_components.update(atoms_j_idx)
        atoms_j = np.random.normal(global_atoms[atoms_j_idx], scale=local_sd)

        # Generating gaussian mixture
        K = atoms_j.shape[0]
        mixing_prop = np.random.dirichlet(np.ones(K))
        assignments = np.random.choice(K, size=M, p=mixing_prop)
        data_j = np.zeros((M, D))

        for k in range(K):
            data_j[assignments == k] = np.random.normal(
                loc=atoms_j[k], scale=0.1, size=((assignments == k).sum(), D))

        data.append(data_j)
        atoms.append(atoms_j)   # Local set of centroids

    return data
