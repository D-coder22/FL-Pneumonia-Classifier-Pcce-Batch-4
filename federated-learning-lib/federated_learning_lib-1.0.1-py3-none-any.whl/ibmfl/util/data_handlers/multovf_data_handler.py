"""
Licensed Materials - Property of IBM
Restricted Materials of IBM
20190891
© Copyright IBM Corp. 2020 All Rights Reserved.
"""
'''
Multiclass Overfit Dataset
Author: Yuya J. Ong (yuyajong@ibm.com)
'''
from __future__ import print_function
import logging
import numpy as np
import pandas as pd

from ibmfl.util.datasets import load_multovf
from sklearn.model_selection import train_test_split
from ibmfl.data.data_handler import DataHandler
from ibmfl.data.pandas_data_handler import PandasDataHandler

logger = logging.getLogger(__name__)

TEST_SIZE = 0.2
RANDOM_STATE = 1234


class MultovfDataHandler(DataHandler):
    """
    Data handler for Multiclass Overfit dataset to train a Multiclass
    Classification Model. TEST_SIZE is set to 0.2, and RANDOM_STATE is set to 42.
    """
    def __init__(self, data_config=None):
        super().__init__()
        self.file_name = None
        if data_config is not None:
            if 'txt_file' in data_config: self.file_name = data_config['txt_file']

    def get_data(self):
        """
        Obtains generated data and splits to test and train sets.

        :param nb_points: Number of data points to be included in each set
        :type nb_points: `int`
        :return: training data
        :rtype: `tuple`
        """
        if self.file_name is None:
            X, y = load_multovf()
        else:
            try:
                logger.info('Loaded training data from ' + str(self.file_name))
                data = pd.read_csv(self.file_name, header=None).to_numpy()
                X, y = data[:, :-1], data[:, -1].astype('int')
            except Exception:
                raise IOError('Unable to load training data from path '
                              'provided in config file: ' + self.file_name)

        # Preprocessing Routine
        X, y = self.preprocess(X, y)

        x_train, x_test, y_train, y_test = train_test_split(
            X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE)

        return (x_train, y_train), (x_test, y_test)

    def preprocess(self, X, y):
        return X, y


class MultovfDTDataHandler(MultovfDataHandler, PandasDataHandler):
    """
    Data handler for Multiclass Overfit dataset to train a multi-class
    classification decision tree Model.
    TEST_SIZE is set to 0.2, and RANDOM_STATE is set to 42.
    """

    def get_data(self):
        """
        Obtains generated data and splits to test and train sets.

        :return: training data and testing data
        :rtype: `tuple`
        """
        if self.file_name is None:
            X, y = load_multovf()
        else:
            try:
                logger.info('Loaded training data from '+ str(self.file_name))
                data = pd.read_csv(self.file_name, header=None).to_numpy()
                X, y = data[:, :-1], data[:, -1].astype('int')
            except Exception:
                raise IOError('Unable to load training data from path '
                              'provided in config file: ' + self.file_name)

        x_train, x_test, y_train, y_test = train_test_split(X, y,
                                                            test_size=TEST_SIZE,
                                                            random_state=RANDOM_STATE)
        # convert to pd.DataFrame and add column names
        y_train = y_train.reshape((len(y_train), 1))
        traindata = np.append(x_train, y_train, axis=1)
        traindata = traindata.astype('int')
        # traindata = pd.DataFrame(data=traindata, columns=[0, 'class'])
        traindata = pd.DataFrame(data=traindata, columns=[0, 1, 2, 'class'])
        traindata[0] = traindata[0].astype('category')
        traindata[1] = traindata[1].astype('category')
        traindata[2] = traindata[2].astype('category')
        traindata['class'] = traindata['class'].astype('category')

        y_test = y_test.reshape((len(y_test), 1))
        testdata = np.append(x_test, y_test, axis=1)
        testdata = testdata.astype('int')
        # testdata = pd.DataFrame(data=testdata, columns=[0, 'class'])
        testdata = pd.DataFrame(data=testdata, columns=[0, 1, 2, 'class'])
        testdata[0] = testdata[0].astype('category')
        testdata[1] = testdata[1].astype('category')
        testdata[2] = testdata[2].astype('category')
        x_test = testdata.drop(['class'], axis=1)
        y_test = testdata['class'].astype('category')
        y_test = y_test.values.tolist()

        return traindata, (x_test, y_test)

    def get_dataset_info(self):
        """
        Read multovf and extract data information

        :return: spec, a dictionary that contains list_of_features, \
        feature_values and list_of_labels.
        :rtype: `dict`
        """
        training_dataset, (_, _) = self.get_data()
        spec = {'list_of_features': list(range(training_dataset.shape[1] - 1))}

        feature_values = []
        for feature in range(training_dataset.shape[1]):
            if training_dataset.columns[feature] != 'class':
                new_feature = training_dataset[
                    training_dataset.columns[feature]].cat.categories
                feature_values.append(new_feature.tolist())
        spec['feature_values'] = feature_values

        list_of_labels = training_dataset['class'].cat.categories
        spec['list_of_labels'] = list_of_labels.tolist()

        return spec


class MultovfKerasDataHandler(MultovfDataHandler):
    def preprocess(self, X, y):
        from keras.utils import to_categorical
        return X, to_categorical(y)
