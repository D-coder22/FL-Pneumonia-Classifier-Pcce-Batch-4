"""
Licensed Materials - Property of IBM
Restricted Materials of IBM
20190891
© Copyright IBM Corp. 2020 All Rights Reserved.
"""
"""
 An enumeration class for the message type field which describe Aggregator status
"""
from enum import Enum


class States(Enum):
    """
    States for Aggregator
    """
    START = 1
    CLI_WAIT = 2
    SND_REQ = 3
    QUORUM_WAIT = 4
    PROC_RSP = 5
    PROC_STOP = 6
    PROC_TRAIN = 7
    PROC_SAVE = 8
    PROC_EVAL = 9
    PROC_SYNC = 10
    REGISTER_WAIT = 11
    PROC_ERROR = 12
